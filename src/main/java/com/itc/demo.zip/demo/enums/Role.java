package com.itc.demo.enums;

public enum Role {
    SUPER_ADMIN,
    ITC_ADMIN,
    FINANCE_ADMIN,
    MISSION_ADMIN,
    VIEWER
}
